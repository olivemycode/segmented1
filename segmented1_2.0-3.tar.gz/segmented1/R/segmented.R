`segmented` <-
function(obj, seg.Z, psi, npsi, fixed.psi=NULL, min_obs = NULL, control=seg.control(), model=TRUE, ...){
            UseMethod("segmented")
            }

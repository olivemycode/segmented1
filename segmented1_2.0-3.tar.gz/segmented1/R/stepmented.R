`stepmented` <-
function(obj, seg.Z, psi, npsi, fixed.psi=NULL, control=seg.control(), keep.class=FALSE, var.psi=FALSE, ...){
            UseMethod("stepmented")
            }
